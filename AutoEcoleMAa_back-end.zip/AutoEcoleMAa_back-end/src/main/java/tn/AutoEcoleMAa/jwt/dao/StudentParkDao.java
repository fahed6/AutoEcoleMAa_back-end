package tn.AutoEcoleMAa.jwt.dao;
import org.springframework.stereotype.Repository;

@Repository
public interface StudentParkDao extends StudentDao{

}
